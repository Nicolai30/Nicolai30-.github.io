# My Mind Mobile — public repository edition

Static offline-first PWA. No analytics, external scripts, server API, accounts, or cloud synchronization. All entries stay in localStorage of the installed origin on the device. Public repository contains only application source and icons.

## Deploy for free with GitHub Pages
1. Create a **public** GitHub repository.
2. Upload only the files from this folder (including `index.html`, `sw.js`, icons and manifest). **Never upload an exported MyMind JSON, screenshots containing private information, or `.env` files.**
3. Settings → Pages → Deploy from branch → main → / (root).
4. Open the resulting HTTPS address in Safari on iPhone → Share → Add to Home Screen.

## Privacy and safety
- GitHub Pages is public. Anyone can read and fork the app code. This is expected.
- **Notes and tasks are not committed or uploaded to GitHub**; they stay on the iPhone.
- Browser storage is **not encrypted** and may be deleted by iOS, browser reset or app removal. Do not store passwords or sensitive company documents.
- Export JSON regularly and save to iCloud Drive/Files; exports contain all private entries in **plaintext**.
- No server-side authentication or encryption is implemented. Public hosting is not a confidential vault.
- Only merge trusted code: a malicious code update on your public website could read local data. Protect the GitHub account with 2FA and avoid third-party scripts.
- The PWA has no automatic iCloud backup and no device-to-device synchronization.
- The app does not claim to prevent data loss completely.
